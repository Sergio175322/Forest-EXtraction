import { DurableObject } from "cloudflare:workers";

const TICK_MS = 100;
const MAP_HALF = 90;
const MAX_ACTIVE = 6;
const EXTRACTION_TIME = 30;
const REVIVE_TIME = 4;
const DOWNED_TIME = 25;
const SANITY_LOW = 30;

function rngFromSeed(seed) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return function () {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function dist2D(ax, az, bx, bz) {
  return Math.hypot(ax - bx, az - bz);
}

function clamp(v, lo, hi) {
  return Math.max(lo, Math.min(hi, v));
}

const LOOT_EFFECT = {
  ammo: { value: 10 },
  medkit: { value: 15, heal: 45 },
  weapon: { value: 50 },
  intel: { value: 80 },
  document: { value: 60 },
  artifact: { value: 150, sanityHit: 8 },
};

function genWorld(seed) {
  const rng = rngFromSeed(seed);
  const trees = [];
  for (let i = 0; i < 160; i++) {
    const x = (rng() - 0.5) * MAP_HALF * 2;
    const z = (rng() - 0.5) * MAP_HALF * 2;
    if (Math.hypot(x, z) < 9) continue;
    trees.push({ x: +x.toFixed(2), z: +z.toFixed(2), s: +(0.8 + rng() * 0.7).toFixed(2), r: +(rng() * 6.28).toFixed(2) });
  }
  const rocks = [];
  for (let i = 0; i < 36; i++) {
    rocks.push({ x: +((rng() - 0.5) * MAP_HALF * 2).toFixed(2), z: +((rng() - 0.5) * MAP_HALF * 2).toFixed(2), s: +(0.6 + rng() * 1.3).toFixed(2) });
  }
  const structures = [
    { kind: "truck", x: 0, z: -6, r: 0 },
    { kind: "checkpoint", x: 34, z: 18, r: 0.4 },
    { kind: "cabin", x: -36, z: 28, r: -0.3 },
    { kind: "bunker", x: 22, z: -46, r: 1.1 },
    { kind: "anomaly", x: -46, z: -34, r: 0 },
  ];
  const lootPoints = [];
  let lid = 0;
  const addLoot = (x, z, type) => lootPoints.push({ id: "l" + lid++, x, z, type });
  addLoot(3, 3, "ammo");
  addLoot(-4, 4, "medkit");
  addLoot(31, 20, "ammo");
  addLoot(36, 16, "intel");
  addLoot(33, 23, "medkit");
  addLoot(30, 14, "weapon");
  addLoot(-34, 31, "intel");
  addLoot(-39, 26, "medkit");
  addLoot(-37, 32, "document");
  addLoot(19, -44, "weapon");
  addLoot(24, -48, "intel");
  addLoot(21, -50, "ammo");
  addLoot(-44, -36, "artifact");
  addLoot(-49, -32, "artifact");
  for (let i = 0; i < 12; i++) {
    addLoot((rng() - 0.5) * MAP_HALF * 1.7, (rng() - 0.5) * MAP_HALF * 1.7, rng() < 0.5 ? "ammo" : "medkit");
  }
  const extractionZones = [
    { x: 0, z: 78, r: 9, name: "Abandoned Road" },
    { x: 78, z: -8, r: 9, name: "Radio Tower" },
    { x: -68, z: 8, r: 9, name: "Flare Pickup" },
  ];
  return { seed, mapHalf: MAP_HALF, trees, rocks, structures, lootPoints, extractionZones };
}

export class GameServer extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.sockets = new Map(); // ws -> connId
    this.connToPlayer = new Map(); // connId -> playerId
    this.playerSockets = new Map(); // playerId -> Set(ws)
    this.players = new Map(); // playerId -> state
    this.world = null;
    this.enemies = [];
    this.lootCollected = new Set();
    this.match = { status: "playing", extraction: null, time: 0, result: null };
    this.tickHandle = null;
    this.connSeq = 0;
    this.alertUntil = 0;
  }

  ensureWorld() {
    if (!this.world) {
      this.world = genWorld((Date.now() ^ Math.floor(Math.random() * 1e9)) >>> 0);
      this.spawnEnemies();
    }
  }

  spawnEnemies() {
    this.enemies = [];
    let eid = 0;
    const infectedSpots = [
      { x: 34, z: 18 },
      { x: 40, z: 14 },
      { x: -36, z: 28 },
      { x: 22, z: -46 },
    ];
    for (const spot of infectedSpots) {
      this.enemies.push({
        id: "e" + eid++,
        kind: "infected",
        x: spot.x,
        z: spot.z,
        homeX: spot.x,
        homeZ: spot.z,
        yaw: 0,
        health: 60,
        maxHealth: 60,
        state: "patrol",
        attackCd: 0,
        respawnAt: 0,
      });
    }
    this.enemies.push({
      id: "stalker",
      kind: "stalker",
      x: -20,
      z: -20,
      yaw: 0,
      health: 999,
      maxHealth: 999,
      state: "lurk",
      attackCd: 0,
      teleportAt: Date.now() + 15000,
      visible: false,
    });
  }

  freshPlayer(id, name) {
    return {
      id,
      name: name || "Soldier",
      x: (Math.random() - 0.5) * 4,
      y: 0,
      z: -2,
      yaw: 0,
      pitch: 0,
      sprinting: false,
      flashlight: true,
      health: 100,
      stamina: 100,
      sanity: 100,
      weapon: "pistol",
      ammo: 12,
      magCap: 12,
      reserve: 36,
      reloading: false,
      reloadEndAt: 0,
      shootCd: 0,
      alive: true,
      downed: false,
      downedAt: 0,
      reviveProgress: 0,
      loot: 0,
      connected: true,
    };
  }

  async fetch(request) {
    const upgrade = request.headers.get("Upgrade");
    if (upgrade !== "websocket") {
      return new Response("blackwood game server", { status: 200 });
    }
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    server.accept();
    const connId = "c" + this.connSeq++;
    this.sockets.set(server, connId);
    server.addEventListener("message", (evt) => this.onMessage(server, connId, evt.data));
    server.addEventListener("close", () => this.onSocketClose(server, connId));
    server.addEventListener("error", () => this.onSocketClose(server, connId));
    this.startTick();
    return new Response(null, { status: 101, webSocket: client });
  }

  send(ws, obj) {
    try {
      ws.send(JSON.stringify(obj));
    } catch (e) {}
  }

  broadcastAll(obj) {
    const msg = JSON.stringify(obj);
    for (const ws of this.sockets.keys()) {
      try {
        ws.send(msg);
      } catch (e) {}
    }
  }

  onMessage(ws, connId, raw) {
    let msg;
    try {
      msg = JSON.parse(raw);
    } catch {
      return this.send(ws, { type: "error", error: "invalid json" });
    }
    this.ensureWorld();

    if (msg.type === "join") {
      const playerId = String(msg.playerId || "").slice(0, 64);
      if (!playerId) return this.send(ws, { type: "error", error: "playerId required" });
      this.connToPlayer.set(connId, playerId);
      if (!this.playerSockets.has(playerId)) this.playerSockets.set(playerId, new Set());
      this.playerSockets.get(playerId).add(ws);
      if (!this.players.has(playerId)) {
        if (this.players.size >= MAX_ACTIVE) {
          return this.send(ws, { type: "error", error: "squad is full" });
        }
        this.players.set(playerId, this.freshPlayer(playerId, msg.name));
      } else {
        this.players.get(playerId).connected = true;
      }
      this.send(ws, { type: "world", world: this.world, you: playerId });
      this.broadcastState();
      return;
    }

    const playerId = this.connToPlayer.get(connId);
    if (!playerId) return this.send(ws, { type: "error", error: "join first" });
    const p = this.players.get(playerId);
    if (!p) return;

    if (msg.type === "move") {
      if (!p.alive) return;
      const half = this.world.mapHalf;
      if (typeof msg.x === "number" && typeof msg.z === "number" && isFinite(msg.x) && isFinite(msg.z)) {
        p.x = clamp(msg.x, -half, half);
        p.z = clamp(msg.z, -half, half);
      }
      if (typeof msg.yaw === "number") p.yaw = msg.yaw;
      if (typeof msg.pitch === "number") p.pitch = msg.pitch;
      p.sprinting = !!msg.sprinting && p.stamina > 1 && !p.downed;
      p.flashlight = !!msg.flashlight;
      return;
    }

    if (msg.type === "action") {
      this.handleAction(p, msg.kind, msg);
      return;
    }

    if (msg.type === "reset") {
      this.resetMatch();
      return;
    }

    return this.send(ws, { type: "error", error: "unknown message type: " + msg.type });
  }

  handleAction(p, kind) {
    if (this.match.status !== "playing") return;
    if (kind === "shoot") {
      if (!p.alive || p.downed) return;
      if (p.reloading) return;
      const now = Date.now();
      if (now < p.shootCd) return;
      if (p.ammo <= 0) return;
      const rate = p.weapon === "rifle" ? 160 : 380;
      p.shootCd = now + rate;
      p.ammo -= 1;
      this.resolveShot(p);
    } else if (kind === "reload") {
      if (!p.alive || p.downed || p.reloading) return;
      if (p.ammo >= p.magCap || p.reserve <= 0) return;
      p.reloading = true;
      p.reloadEndAt = Date.now() + 1400;
    } else if (kind === "interact") {
      this.handleInteract(p);
    } else if (kind === "callExtraction") {
      this.tryCallExtraction(p);
    }
  }

  resolveShot(p) {
    const dmg = p.weapon === "rifle" ? 30 : 20;
    const range = p.weapon === "rifle" ? 55 : 40;
    const eyeX = p.x,
      eyeZ = p.z;
    const dirX = -Math.sin(p.yaw) * Math.cos(p.pitch);
    const dirZ = -Math.cos(p.yaw) * Math.cos(p.pitch);
    let best = null,
      bestT = range;
    for (const e of this.enemies) {
      if (e.health <= 0) continue;
      const toX = e.x - eyeX,
        toZ = e.z - eyeZ;
      const dist = Math.hypot(toX, toZ);
      if (dist > range) continue;
      const dot = (toX * dirX + toZ * dirZ) / (dist || 1);
      if (dot < 0.92) continue; // narrow cone = aim accuracy
      if (dist < bestT) {
        bestT = dist;
        best = e;
      }
    }
    this.broadcastAll({ type: "event", kind: "shot", by: p.id, x: eyeX, z: eyeZ, yaw: p.yaw });
    if (best) {
      best.health -= dmg;
      best.alertedAt = Date.now() + 6000;
      if (best.kind === "infected" && best.health <= 0) {
        best.health = 0;
        best.state = "dead";
        best.respawnAt = Date.now() + 18000;
      } else if (best.kind === "stalker" && best.health < best.maxHealth * 0.4) {
        best.state = "flee";
        best.teleportAt = Date.now() + 800;
      }
      this.broadcastAll({ type: "event", kind: "hit", target: best.id });
    }
    // gunfire alerts nearby infected
    for (const e of this.enemies) {
      if (e.kind === "infected" && e.health > 0) {
        const d = dist2D(e.x, e.z, eyeX, eyeZ);
        if (d < 45) e.alertedAt = Date.now() + 6000;
      }
    }
    this.alertUntil = Math.max(this.alertUntil, Date.now() + 4000);
  }

  handleInteract(p) {
    // revive a nearby downed teammate first
    for (const other of this.players.values()) {
      if (other.id === p.id || !other.downed || !other.alive) continue;
      if (dist2D(p.x, p.z, other.x, other.z) < 3) {
        other.reviveProgress = (other.reviveProgress || 0) + TICK_MS / 1000;
        if (other.reviveProgress >= REVIVE_TIME) {
          other.downed = false;
          other.health = 45;
          other.reviveProgress = 0;
        }
        return;
      }
    }
    // pick up nearest uncollected loot in range
    let nearest = null,
      nd = 3.2;
    for (const lp of this.world.lootPoints) {
      if (this.lootCollected.has(lp.id)) continue;
      const d = dist2D(p.x, p.z, lp.x, lp.z);
      if (d < nd) {
        nd = d;
        nearest = lp;
      }
    }
    if (nearest) {
      this.lootCollected.add(nearest.id);
      const fx = LOOT_EFFECT[nearest.type] || { value: 5 };
      p.loot += fx.value;
      if (fx.heal) p.health = clamp(p.health + fx.heal, 0, 100);
      if (fx.sanityHit) p.sanity = clamp(p.sanity - fx.sanityHit, 0, 100);
      if (nearest.type === "ammo") p.reserve = clamp(p.reserve + 24, 0, 240);
      if (nearest.type === "weapon" && p.weapon !== "rifle") {
        p.weapon = "rifle";
        p.magCap = 30;
        p.ammo = 30;
        p.reserve += 60;
      }
      this.broadcastAll({ type: "event", kind: "loot", by: p.id, lootType: nearest.type });
    }
  }

  tryCallExtraction(p) {
    if (this.match.extraction && this.match.extraction.active) return;
    for (const z of this.world.extractionZones) {
      if (dist2D(p.x, p.z, z.x, z.z) < z.r) {
        this.match.extraction = { active: true, zone: z, timeLeft: EXTRACTION_TIME };
        this.alertUntil = Date.now() + (EXTRACTION_TIME + 5) * 1000;
        this.broadcastAll({ type: "event", kind: "extraction_called", zone: z.name });
        for (const e of this.enemies) e.alertedAt = Date.now() + (EXTRACTION_TIME + 5) * 1000;
        return;
      }
    }
  }

  resetMatch() {
    this.world = genWorld((Date.now() ^ Math.floor(Math.random() * 1e9)) >>> 0);
    this.spawnEnemies();
    this.lootCollected = new Set();
    this.match = { status: "playing", extraction: null, time: 0, result: null };
    for (const p of this.players.values()) {
      const fresh = this.freshPlayer(p.id, p.name);
      Object.assign(p, fresh);
    }
    this.broadcastAll({ type: "world", world: this.world, you: null });
  }

  onSocketClose(ws, connId) {
    this.sockets.delete(ws);
    const playerId = this.connToPlayer.get(connId);
    this.connToPlayer.delete(connId);
    if (playerId && this.playerSockets.has(playerId)) {
      this.playerSockets.get(playerId).delete(ws);
      if (this.playerSockets.get(playerId).size === 0) {
        const p = this.players.get(playerId);
        if (p) p.connected = false;
      }
    }
    if (this.sockets.size === 0 && this.tickHandle) {
      clearInterval(this.tickHandle);
      this.tickHandle = null;
    } else {
      this.broadcastState();
    }
  }

  startTick() {
    if (this.tickHandle) return;
    this.tickHandle = setInterval(() => this.tick(), TICK_MS);
  }

  tick() {
    if (!this.world) return;
    const dt = TICK_MS / 1000;
    const now = Date.now();

    // player regen/drain
    let aliveCount = 0;
    for (const p of this.players.values()) {
      if (!p.connected) continue;
      if (!p.alive) continue;
      aliveCount++;
      if (p.downed) {
        if (now - p.downedAt > DOWNED_TIME * 1000) {
          p.alive = false;
          p.loot = 0;
        }
        continue;
      }
      // stamina
      if (p.sprinting) p.stamina = clamp(p.stamina - 14 * dt, 0, 100);
      else p.stamina = clamp(p.stamina + 10 * dt, 0, 100);
      // sanity
      let nearestMate = 999;
      for (const other of this.players.values()) {
        if (other.id === p.id || !other.alive || other.downed) continue;
        nearestMate = Math.min(nearestMate, dist2D(p.x, p.z, other.x, other.z));
      }
      let sanityDelta = nearestMate < 14 ? 1.2 * dt : -0.6 * dt;
      const anomaly = this.world.structures.find((s) => s.kind === "anomaly");
      if (anomaly && dist2D(p.x, p.z, anomaly.x, anomaly.z) < 16) sanityDelta -= 3 * dt;
      const stalker = this.enemies.find((e) => e.kind === "stalker");
      if (stalker) {
        const ds = dist2D(p.x, p.z, stalker.x, stalker.z);
        if (ds < 20) sanityDelta -= (20 - ds) * 0.25 * dt;
      }
      p.sanity = clamp(p.sanity + sanityDelta, 0, 100);
      // reload completion
      if (p.reloading && now >= p.reloadEndAt) {
        const need = p.magCap - p.ammo;
        const take = Math.min(need, p.reserve);
        p.ammo += take;
        p.reserve -= take;
        p.reloading = false;
      }
    }

    // enemy AI
    const aggressive = this.match.extraction && this.match.extraction.active;
    for (const e of this.enemies) {
      if (e.kind === "infected") {
        if (e.health <= 0) {
          if (now >= e.respawnAt && e.respawnAt > 0) {
            e.health = e.maxHealth;
            e.x = e.homeX;
            e.z = e.homeZ;
            e.state = "patrol";
            e.respawnAt = 0;
          }
          continue;
        }
        let target = null,
          td = 9999;
        for (const p of this.players.values()) {
          if (!p.alive || p.downed || !p.connected) continue;
          const d = dist2D(e.x, e.z, p.x, p.z);
          if (d < td) {
            td = d;
            target = p;
          }
        }
        const detect = aggressive ? 30 : e.alertedAt > now ? 26 : 16;
        if (target && td < detect) {
          e.state = "chase";
          const dx = target.x - e.x,
            dz = target.z - e.z;
          const len = Math.hypot(dx, dz) || 1;
          const spd = 4.6;
          if (len > 2) {
            e.x += (dx / len) * spd * dt;
            e.z += (dz / len) * spd * dt;
          }
          e.yaw = Math.atan2(-dx, -dz);
          if (len < 2.2 && e.attackCd < now) {
            target.health = clamp(target.health - 9, 0, 100);
            e.attackCd = now + 1100;
            this.broadcastAll({ type: "event", kind: "playerHit", target: target.id });
            if (target.health <= 0 && !target.downed) {
              target.downed = true;
              target.downedAt = now;
            }
          }
        } else {
          e.state = "patrol";
          const dx = e.homeX - e.x,
            dz = e.homeZ - e.z;
          const len = Math.hypot(dx, dz);
          if (len > 1.5) {
            e.x += (dx / len) * 1.4 * dt;
            e.z += (dz / len) * 1.4 * dt;
            e.yaw = Math.atan2(-dx, -dz);
          }
        }
      } else if (e.kind === "stalker") {
        let target = null,
          td = 9999;
        const lonely = [];
        for (const p of this.players.values()) {
          if (!p.alive || p.downed || !p.connected) continue;
          const d = dist2D(e.x, e.z, p.x, p.z);
          if (d < td) {
            td = d;
            target = p;
          }
          let nearMate = 999;
          for (const o of this.players.values()) {
            if (o.id === p.id || !o.alive) continue;
            nearMate = Math.min(nearMate, dist2D(p.x, p.z, o.x, o.z));
          }
          if (nearMate > 22 || p.sanity < SANITY_LOW) lonely.push(p);
        }
        const hunting = aggressive || lonely.length > 0;
        if (e.state === "flee") {
          if (now >= e.teleportAt) {
            const ang = Math.random() * 6.28,
              rad = 30 + Math.random() * 20;
            e.x = clamp((target ? target.x : 0) + Math.cos(ang) * rad, -MAP_HALF, MAP_HALF);
            e.z = clamp((target ? target.z : 0) + Math.sin(ang) * rad, -MAP_HALF, MAP_HALF);
            e.health = e.maxHealth;
            e.state = "lurk";
            e.teleportAt = now + 18000 + Math.random() * 12000;
            e.visible = false;
          }
        } else if (target && hunting && td < 60) {
          e.state = "hunt";
          e.visible = td < 30;
          const dx = target.x - e.x,
            dz = target.z - e.z;
          const len = Math.hypot(dx, dz) || 1;
          const spd = 6.8;
          if (len > 1.8) {
            e.x += (dx / len) * spd * dt;
            e.z += (dz / len) * spd * dt;
          }
          e.yaw = Math.atan2(-dx, -dz);
          if (len < 2.4 && e.attackCd < now) {
            target.health = clamp(target.health - 26, 0, 100);
            e.attackCd = now + 1600;
            this.broadcastAll({ type: "event", kind: "playerHit", target: target.id });
            if (target.health <= 0 && !target.downed) {
              target.downed = true;
              target.downedAt = now;
            }
          }
        } else {
          if (now >= e.teleportAt) {
            const ang = Math.random() * 6.28,
              rad = 35 + Math.random() * 25;
            const base = target || { x: 0, z: 0 };
            e.x = clamp(base.x + Math.cos(ang) * rad, -MAP_HALF, MAP_HALF);
            e.z = clamp(base.z + Math.sin(ang) * rad, -MAP_HALF, MAP_HALF);
            e.teleportAt = now + 20000 + Math.random() * 15000;
            this.broadcastAll({ type: "event", kind: "growl" });
          }
          e.state = "lurk";
          e.visible = target ? td < 26 && Math.random() < 0.3 : false;
        }
      }
    }

    // extraction timer
    if (this.match.extraction && this.match.extraction.active) {
      this.match.extraction.timeLeft -= dt;
      if (this.match.extraction.timeLeft <= 0) {
        const z = this.match.extraction.zone;
        const results = {};
        let anySuccess = false;
        for (const p of this.players.values()) {
          if (p.alive && !p.downed && dist2D(p.x, p.z, z.x, z.z) < z.r) {
            results[p.id] = { success: true, loot: p.loot };
            anySuccess = true;
          } else {
            results[p.id] = { success: false, loot: 0 };
          }
        }
        this.match.status = "over";
        this.match.result = { outcome: anySuccess ? "extracted" : "left_behind", results };
        this.match.extraction.active = false;
      }
    }
    if (this.match.status === "playing" && aliveCount === 0 && this.players.size > 0) {
      this.match.status = "over";
      this.match.result = { outcome: "wiped", results: {} };
    }

    this.broadcastState();
  }

  broadcastState() {
    if (!this.world) return;
    const players = [...this.players.values()].map((p) => ({
      id: p.id,
      name: p.name,
      x: p.x,
      y: p.y,
      z: p.z,
      yaw: p.yaw,
      pitch: p.pitch,
      sprinting: p.sprinting,
      flashlight: p.flashlight,
      health: Math.round(p.health),
      stamina: Math.round(p.stamina),
      sanity: Math.round(p.sanity),
      weapon: p.weapon,
      ammo: p.ammo,
      magCap: p.magCap,
      reserve: p.reserve,
      reloading: p.reloading,
      alive: p.alive,
      downed: p.downed,
      reviveProgress: p.reviveProgress || 0,
      loot: p.loot,
      connected: p.connected,
    }));
    const enemies = this.enemies.map((e) => ({
      id: e.id,
      kind: e.kind,
      x: e.x,
      z: e.z,
      yaw: e.yaw,
      state: e.state,
      health: e.health,
      maxHealth: e.maxHealth,
      visible: e.kind === "stalker" ? !!e.visible : e.health > 0,
    }));
    this.broadcastAll({
      type: "state",
      status: this.match.status,
      players,
      enemies,
      lootCollected: [...this.lootCollected],
      extraction: this.match.extraction,
      result: this.match.result,
    });
  }
}

export default {
  fetch() {
    return new Response("Operation Blackwood: Extraction — game server module", { status: 200 });
  },
};
